//
//  ViewController.swift
//  Proyecto Final
//
//  Created by MacBook on 11/16/18.
//  Copyright © 2018 ioslab. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var instrucciones: Etiqueta!
    @IBOutlet weak var botonSalir: Botoncito!
    @IBOutlet weak var botonBuscar: Botoncito!
    @IBOutlet weak var textoBusqueda: BarraDeTexto!
    @IBOutlet weak var tablaBusqueda: UITableView!
    
    var listaTiendas : [Tienda] = []
    /*[Tienda(nombre: "Puesto 2", localizacion: "A un lado de don rata", precioMedio: 60.50, tiempoMedio: 18, saludable: false, latitud: 19.32722, longitud: -99.18288), Tienda(nombre: "Don rata", localizacion: "En la entrada norte del anexo, junto a las papelerias", precioMedio: 45.00, tiempoMedio: 20, saludable: false, latitud: 19.322727, longitud: -99.18289), Tienda(nombre: "Tacos de canasta", localizacion: "En algun lugar de un gran pais", precioMedio: 5.00, tiempoMedio: 1, saludable: false, latitud: 19.32713, longitud: -99.18278)*//*, Tienda(nombre: "Ciencias", localizacion: "Pues en ciencias", precioMedio: 26.00, tiempoMedio: 25, saludable: false, latitud: 10, longitud: 10), Tienda(nombre: "Local del principal", localizacion: "En el principal por la entrada del pumabus", precioMedio: 28.50, tiempoMedio: 14, saludable: true, latitud: 10, longitud: 10)]*/
    var listaDeBusqueda : [Tienda] = []
    var caso : Int = 0
    var diccionario : Dictionary = ["averagePrice" : 35, "averageTime" : 20, "healthy" : false, "latitude" : 19.3272002, "location" : "Entrando al enexo de ingenieria", "longitude" : -99.1827926, "name" : "Barra 2"] as [String : Any]
    override func viewDidLoad() {
        super.viewDidLoad()
        let db = Firestore.firestore()
        db.collection("shops").getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                    print("\(document.documentID) => \(document.data())")
                    self.diccionario = document.data()
                    print(self.diccionario["averagePrice"]!)
                    self.listaTiendas.append(Tienda(nombre: self.diccionario["name"]! as! String, localizacion: self.diccionario["location"]! as! String, precioMedio: self.diccionario["averagePrice"]! as! Double, tiempoMedio: self.diccionario["averageTime"]! as! Int, saludable: self.diccionario["healthy"]! as! Bool, latitud: self.diccionario["latitude"]! as! Double, longitud: self.diccionario["longitude"]! as! Double))
                    print(self.listaTiendas[0])
                }
            }
        }
        botonSalir.setTitle("Regresar", for: .normal)
        botonBuscar.setTitle("Buscar", for: .normal)
        caso+=1
        
        if caso<4 {
            instrucciones.text = "Ingrese la palabra que desea buscar o la cantidad maxima a buscar"
        }else{
            instrucciones.text = "Estos son los establecimientos con comida saludable"
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaDeBusqueda.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ResultadoBusqueda", for: indexPath)
        cell.textLabel?.text = listaDeBusqueda[(indexPath.row)].nombre
        return cell
    }
    
    @IBAction func busqueda(_ sender: Any) {
        var texto : String
        var numero: Double
        texto = textoBusqueda.text!
        numero = Double(texto) ?? 0
        //print(numero) para verificar que el numero coincide con el introducido
        listaDeBusqueda = []
        //print(caso)  Es para verificar que el caso es correcto
        switch caso {
        case 1: //Por localizacion
            for iterador in listaTiendas{
                if iterador.localizacion.range(of:texto) != nil {
                    listaDeBusqueda.append(iterador)
                }
            }
        //print(listaDeBusqueda) para verificar que la cadena esta en la lista y si esta lo agrega
        case 2:// Economico
            for precioIterador in listaTiendas{
                if (precioIterador.precioMedio<=numero){
                    listaDeBusqueda.append(precioIterador)
                }
            }
        case 3://Express
            for tiempoIterador in listaTiendas{
                if (tiempoIterador.tiempoMedio<=Int(numero)){
                    listaDeBusqueda.append(tiempoIterador)
                }
            }
        case 4://Saludable
            for saludableIterador in listaTiendas{
                if(saludableIterador.saludable){
                    listaDeBusqueda.append(saludableIterador)
                }
            }
        default:
            listaDeBusqueda = []
        }
       tablaBusqueda.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vistaDestino = segue.destination as? FifthViewController
        let indexPath = tablaBusqueda.indexPathForSelectedRow
        vistaDestino?.objetivo = listaDeBusqueda[(indexPath?.row)!]
    }
    
    @IBAction  func unwindView(for unwindSegue: UIStoryboardSegue) {
    }
}

