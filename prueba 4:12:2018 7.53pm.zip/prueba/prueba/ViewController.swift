//
//  ViewController.swift
//  prueba
//
//  Created by user141381 on 12/4/18.
//  Copyright © 2018 user141381. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ViewController: UIViewController {
    @IBOutlet weak var myTextField: UITextField!
    var ref:DatabaseReference!
    
    @IBAction func myButton(_ sender: UIButton) {
        ref = Database.database().reference() //
        ref.child("list").childByAutoId().setValue(myTextField.text)  //Agrega texto a la base de datos
        myTextField.text = "" //Reinicia el texfield
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

